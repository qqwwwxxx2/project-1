document.getElementById("redirectButton").addEventListener("click", function() {
    window.open("image 1.html", "_blank");
});


